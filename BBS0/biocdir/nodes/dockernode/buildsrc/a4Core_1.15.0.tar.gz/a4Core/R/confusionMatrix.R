confusionMatrix <- function(x, ...){ # common to a4Classif (pamClass) and nlcv
  UseMethod("confusionMatrix")
}



